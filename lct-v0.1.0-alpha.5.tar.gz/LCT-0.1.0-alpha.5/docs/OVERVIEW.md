# Documentation

Docs aren't implemented yet

## Assembler / Preprocessor

Docs are planned

## Linker

Docs are planned

## Buildtool

Docs are planned

## Filesystem Tool

Docs are planned

## Joke Tool

Docs are planned

## Brainfuck Interpreter

Docs are planned
