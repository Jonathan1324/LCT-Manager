# LCT

Collection of Command-line Tools

## Name

LCT is a collection of command-line interface tools.
The ‘CT’ can stand for either ‘Collection of Tools’ or ‘Command-line Tools’.
The meaning of the ‘L’ has not yet been determined.

## Documentation

[Docs](./docs/OVERVIEW.md)

## License

This project is licensed under the [BSD 3-Clause License](LICENSE).
