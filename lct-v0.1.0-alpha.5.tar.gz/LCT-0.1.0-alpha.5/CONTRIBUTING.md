# Contributing

Open an issue or a pull request.  

- Work on the `main` branch.  
- Follow existing code style.  
- If you can, test your changes locally with the buildtool.  
