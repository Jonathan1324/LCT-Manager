#include "help.h"

#include <stdio.h>

void printHelp()
{
    fputs("The linker isn't implemented yet. :(\n", stdout);
}