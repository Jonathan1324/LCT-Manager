#pragma once
#include <cpp/cpp.h>

HCB

void printHelp();

HCE