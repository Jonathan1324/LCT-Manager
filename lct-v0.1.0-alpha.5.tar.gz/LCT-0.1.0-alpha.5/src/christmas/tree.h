#pragma once

int printTree(int height, int trunkHeight, int trunkWidth, int color, int dense, int ornaments);
