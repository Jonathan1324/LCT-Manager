#pragma once
#include <time.h>

void printCountdown(const char* label, time_t seconds);
