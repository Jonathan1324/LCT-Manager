pub struct Context {
    pub rebuild: bool,
    pub mode: Option<String>,
}
