#pragma once

extern const char* jokes[];

extern const unsigned int joke_count;
