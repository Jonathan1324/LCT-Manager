#pragma once

#ifdef __cplusplus
#define HCB extern "C" {
#define HCE }
#else
#define HCB
#define HCE
#endif