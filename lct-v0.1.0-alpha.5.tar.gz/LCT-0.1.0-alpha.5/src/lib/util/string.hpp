#pragma once
#include <string>

std::string trim(const std::string& str);
std::string toLower(const std::string& input);