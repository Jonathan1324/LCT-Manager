#pragma once

#include "cpp/cpp.h"

HCB

#define VERSION "v0.1.0-alpha.5"

void printVersion();

HCE
