#pragma once

#include "tape.h"

void interpret(char* program, uint64_t* meta, uint64_t programSize);
