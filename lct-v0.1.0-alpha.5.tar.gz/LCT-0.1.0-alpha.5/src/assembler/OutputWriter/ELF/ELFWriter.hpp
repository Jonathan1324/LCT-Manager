#pragma once

#include "../OutputWriter.hpp"
#include "Headers.hpp"

namespace ELF
{
    struct RelocationSection
    {
        std::vector<uint8_t> buffer;
        std::string name;

        std::variant<SectionHeader32, SectionHeader64> header;
    };

    struct Section
    {
        std::vector<uint8_t>* buffer;
        std::string name;

        bool writeBuffer = true;
        
        std::variant<SectionHeader32, SectionHeader64> header;

        std::vector<Encoder::Relocation> relocations;
        bool hasRelocations = false;
        bool hasAddend = false;

        bool nullSection = false;
    };

    class Writer : public Output::Writer
    {
    public:
        Writer(const Context& _context, Architecture _arch, BitMode _bits, Format _format, std::ostream* _file, const Parser::Parser* _parser, const Encoder::Encoder* _encoder);
        ~Writer() = default;

        void Write() override;

    protected:
        std::vector<Section> sections;
        std::vector<RelocationSection> relocationSections;

        using SymbolEntry = std::variant<Symbol::Entry32, Symbol::Entry64>;
        std::vector<SymbolEntry> localSymbols;
        std::vector<SymbolEntry> globalSymbols;
        std::vector<SymbolEntry> weakSymbols;

        uint64_t getSectionFlags(const std::string& name);
        uint32_t getSectionType(const std::string& name);
    };
}
