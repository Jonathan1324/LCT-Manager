#pragma once

#include <string>
#include <unordered_map>
#include <cstdint>

uint64_t evalInteger(std::string str, size_t size, int lineNumber, int column);