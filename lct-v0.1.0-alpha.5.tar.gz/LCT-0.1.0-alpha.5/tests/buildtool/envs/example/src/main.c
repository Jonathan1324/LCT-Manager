#include <stdio.h>
#include "test.h"

int main() {
    printf("Hello, World!\n");
    printf("result = %i\n", test());
    printf("%i\n", again());
    return 0;
}
