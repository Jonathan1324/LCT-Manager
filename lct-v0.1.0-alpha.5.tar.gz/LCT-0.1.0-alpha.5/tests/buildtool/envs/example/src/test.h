#pragma once

int test();
int again();
