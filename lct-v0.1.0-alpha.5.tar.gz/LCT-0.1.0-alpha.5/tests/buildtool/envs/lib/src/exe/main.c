#include <stdio.h>

int TestFunc();

int main() {
    printf("Hello, World!\n%i\n", TestFunc());
    return 0;
}