dist/bin/ljoke $@
