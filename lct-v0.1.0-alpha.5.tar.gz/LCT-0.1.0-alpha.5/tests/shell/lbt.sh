cd tests/buildtool/envs/test

../../../../dist/bin/lbt $@

cd ../../../..
